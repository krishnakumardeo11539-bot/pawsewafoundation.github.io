PAWSEWA FOUNDATION website
==========================

This is a static website ready for GitHub Pages.

Files:
- index.html
- style.css
- script.js

Before publishing:
1. Replace the placeholder email and phone number.
2. Add your official donation UPI/bank details and QR code.
3. Replace any wording you want to customize.
4. Connect pawsewafoundation.in to GitHub Pages.

Verified registration information used in this template:
- PAWSEWA FOUNDATION
- Section 8 company
- CIN: U88900JH2026NPL028969
- Section 8 Licence: 191180
- Incorporation date: 31 August 2026
- Registered office: C/O Bipin Kumar Ganga, Ratu Road, Ranchi, Ratu, Ratu, Ranchi - 835222, Jharkhand

Note: The website does not claim 80G approval because the supplied incorporation documents do not establish that certificate.
